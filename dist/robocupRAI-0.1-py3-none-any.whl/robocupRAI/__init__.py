from robocupRAI.insert import *
from robocupRAI.query import *
from robocupRAI.config import *